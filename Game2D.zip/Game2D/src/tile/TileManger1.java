package tile;

import game2d.GamePanle;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;



public class TileManger1 {
    
    //هذا tileكلاسس عباره عن كلاس
public class Tile {
    public BufferedImage image;
    public boolean collision = false; // خاصية التصادم
    
    
}
    GamePanle gp;
  public  Tile[] tile;
   public int[][] mapTileNum;

    public TileManger1(GamePanle gp) {
        this.gp = gp;
        // عدد البلاط الذي سيتم إضافته
        tile = new Tile[10];
        mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
        getTileImage();
        loadMap();
    }

    public void getTileImage() {
        try {
            tile[0] = new Tile();
            tile[0].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\res\\player\\tiles\\grass.png"));
            tile[0].collision = false; // لا يوجد تصادم

            tile[1] = new Tile();
            tile[1].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\res\\player\\tiles\\wall.png"));
            tile[1].collision = true; // تصادم
           tile[1].collision=false;
            tile[2] = new Tile();
            tile[2].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\res\\player\\tiles\\water.png"));
            tile[2].collision = true; // تصادم

            tile[3] = new Tile();
            tile[3].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\tile\\earth.png"));
            tile[3].collision = false; // لا يوجد تصادم

            tile[4] = new Tile();
            tile[4].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\tile\\drytree.png"));
            tile[4].collision = true; // تصادم

            tile[5] = new Tile();
            tile[5].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\tile\\sand.png"));
            tile[5].collision = false; // لا يوجد تصادم
             
            
            tile[6] = new Tile();
            tile[6].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\tile\\Opject\\key.png"));
            tile[6].collision = false; // لا يوجد تصادم
            
            tile[7] = new Tile();
            tile[7].image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\tile\\Opject\\6cf18166158875.5b0cfedc7e7f7.jpg"));
            tile[7].collision = false; // لا يوجد تصادم
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadMap() {
        try {
            // تصحيح المسار للتأكد من أنه صحيح
            InputStream is = getClass().getResourceAsStream("/res/player/maps/world01.txt");
            if (is == null) {
                System.out.println("File not found: /res/player/maps/world01.txt");
                return; // إنهاء التنفيذ إذا لم يتم العثور على الملف
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int col = 0;
            int row = 0;

            while (row < gp.maxWorldRow) { // التحقق من الصفوف أولاً
                String line = br.readLine();
                if (line == null) {
                    System.out.println("End of file reached or line is null.");
                    break; // إنهاء الحلقة إذا وصلنا إلى نهاية الملف
                }

                String[] numbers = line.split(" ");
                col = 0; // إعادة تعيين العمود في كل سطر
                while (col < gp.maxWorldCol) {
                    if (col < numbers.length) { // التأكد من أن العمود الحالي موجود في السطر
                        int num = Integer.parseInt(numbers[col]);
                        mapTileNum[col][row] = num;
                        col++;
                    } else {
                        System.out.println("Not enough columns in line: " + line);
                        break; // إنهاء الحلقة إذا كانت هناك أعمدة أقل من المتوقع
                    }
                }

                row++;
//                if (  tile[2].collision = true) {
//                     tile[2].collision =false;
//                    Player p=new Player(gp, null);
//                    
//                }
            }

            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void draw(Graphics2D g2) {
        int worldCol = 0;
        int worldRow = 0;

        while (worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow) {
            int tileNum = mapTileNum[worldCol][worldRow];

            int worldX = worldCol * gp.tileSize;
            int worldY = worldRow * gp.tileSize;
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            // رسم البلاط فقط إذا كان ضمن نطاق الشاشة
//            if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
//                worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
//                worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
//                worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
//                if (worldX +gp.tileSize>gp.player.worldX-gp.player.screenX &&worldX -gp.tileSize<gp.player.worldX + gp.player.screenX
//                        &&worldY+gp.tileSize>gp.player.worldY-gp.player.screenY &&worldX-gp.tileSize<gp.player.worldY + gp.player.screenY
//                        )   {
             g2.drawImage(tile[tileNum].image, screenX, screenY, gp.tileSize, gp.tileSize, null);
               // }
          //  }

            worldCol++;

            if (worldCol == gp.maxWorldCol) {
                worldCol = 0;
                worldRow++;
            }
        }
    }
}
