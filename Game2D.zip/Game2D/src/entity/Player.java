package entity;

import game2d.GamePanle;
import game2d.KyeHandler;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Player extends Entity {

    GamePanle gp;
    KyeHandler keyH;
    final int originalTileSize = 16;
    final int scale = 3;
    public int tileSize = originalTileSize * scale;
    public final int screenX;
    public final int screenY;

    private boolean isMoving = false; // Add this line to track movement status
    private boolean isShooting = false; // To track if the player is shooting

    // Variables for bullet
    private int bulletX, bulletY;
    private int bulletSpeed = 5;
    private boolean bulletActive = false;
    private String bulletDirection = "right";

    public Player(GamePanle gp, KyeHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;
        screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
        screenY = gp.screenHeight / 2 - (gp.tileSize / 2);
        solidArea = new Rectangle();
        solidArea.x = 0;
        solidArea.y = 10;
        solidArea.width = 10;
        solidArea.height = 12;
        setDefaultValues();
        getPlayerImage();
    }

    public void setDefaultValues() {
        worldX = gp.tileSize * 23;
        worldY = gp.tileSize * 21;
        speed = 4;
        direction = "down";
    }

    BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;
    BufferedImage dup1, dup2, ddown1, ddown2, dright1, dright2, dleft1, dleft2;
    BufferedImage idleImage, sideImage, sideImage2, idleImage2;

    public void getPlayerImage() {
        try {
            up1 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_up_1.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_up_2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_down_1.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_down_2.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_left_1.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_left_2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_right_1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_right_2.png"));
            dup1 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_015650-removebg-preview.png"));
            dup2 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_015654-removebg-preview.png"));
            ddown1 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_020446-removebg-preview.png"));
            ddown2 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_020451-removebg-preview.png"));
            dright1 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_014612-removebg-preview.png"));
            dright2 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_015133-removebg-preview.png"));
            dleft1 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_015930-removebg-preview.png"));
            dleft2 = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_015939-removebg-preview.png"));
            idleImage = ImageIO.read(getClass().getResourceAsStream("/entity/Screenshot_2024-08-23_020755-removebg-preview.png"));
            idleImage2 = ImageIO.read(getClass().getResourceAsStream("/game2d/Screenshot_2024-08-23_183616-removebg-preview.png"));
            sideImage = ImageIO.read(getClass().getResourceAsStream("/game2d/Screenshot_2024-08-23_181237-removebg-preview.png"));
            sideImage2 = ImageIO.read(getClass().getResourceAsStream("/game2d/Screenshot_2024-08-23_181223-removebg-preview.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getX() {
        return worldX; // Assuming worldX represents the player's X coordinate
    }

    public int getY() {
        return worldY; // Assuming worldY represents the player's Y coordinate
    }

    public void update() {
        isMoving = false; // Reset movement status
        isShooting = false; // Reset shooting status

        if (keyH.upPreassed) {
            direction = "up";
            isMoving = true;
        }
        if (keyH.downPreassed) {
            direction = "down";
            isMoving = true;
        }
        if (keyH.leftPreassed) {
            direction = "left";
            isMoving = true;
        }
        if (keyH.rightPreassed) {
            direction = "right";
            isMoving = true;
        }

        if (isMoving) {
            collisionOn = false;
            gp.collCheck.checkTile(this);
            if (!collisionOn) {
                switch (direction) {
                    case "up":
                        worldY -= speed;
                        break;
                    case "down":
                        worldY += speed;
                        break;
                    case "left":
                        worldX -= speed;
                        break;
                    case "right":
                        worldX += speed;
                        break;
                }
            }

            spriteCounter++;
            if (spriteCounter > 10) {
                spriteNum = (spriteNum == 1) ? 2 : 1;
                spriteCounter = 0;
            }
        }

        // Update bullet position
        if (bulletActive) {
            switch (bulletDirection) {
                case "up":
                    bulletY -= bulletSpeed;
                    break;
                case "down":
                    bulletY += bulletSpeed;
                    break;
                case "left":
                    bulletX -= bulletSpeed;
                    break;
                case "right":
                    bulletX += bulletSpeed;
                    break;
            }
            // Check if the bullet is out of bounds and deactivate it if necessary
            if (bulletX < 0 || bulletX > gp.screenWidth || bulletY < 0 || bulletY > gp.screenHeight) {
                bulletActive = false;
            }
        }
    }

    public void paintComponent(Graphics2D g2) {
        BufferedImage image = null;
        BufferedImage dimage = null;
        BufferedImage sideImageToDraw = null;

        if (isMoving) {
            switch (direction) {
                case "up":
                    image = (spriteNum == 1) ? up1 : up2;
                    dimage = (spriteNum == 1) ? dup1 : dup2;
                    break;
                case "down":
                    image = (spriteNum == 1) ? down1 : down2;
                    dimage = (spriteNum == 1) ? ddown1 : ddown2;
                    break;
                case "left":
                    image = (spriteNum == 1) ? left1 : left2;
                    dimage = (spriteNum == 1) ? dleft1 : dleft2;
                    break;
                case "right":
                    image = (spriteNum == 1) ? right1 : right2;
                    dimage = (spriteNum == 1) ? dright1 : dright2;
                    break;
                default:
                    throw new AssertionError();
            }

            int playerX = gp.screenWidth / 2 - (tileSize / 2);
            int playerY = gp.screenHeight / 2 - (tileSize / 2);
            int dimageX = gp.screenWidth - 430 - (tileSize / 2);
            int dimageY = gp.screenHeight / 2 - (tileSize / 2);

            g2.drawImage(image, playerX, playerY, tileSize, tileSize, null);

            if (dimage != null) {
                g2.drawImage(dimage, dimageX, dimageY, tileSize, tileSize, null);
            }
        } else {
            sideImageToDraw = (spriteNum == 1) ? sideImage : sideImage2;
            
            g2.drawImage(idleImage, gp.screenWidth / 2 - (tileSize / 2), gp.screenHeight / 2 - (tileSize / 2), tileSize, tileSize, null);
            if (keyH.spacePreassed) {
                g2.drawImage(idleImage2, gp.screenWidth / 2 - (tileSize / 2), gp.screenHeight / 2 - (tileSize / 2), 90, tileSize, null);
            }
            
            if (sideImageToDraw != null) {
                g2.drawImage(sideImageToDraw, gp.screenWidth - 330 - (tileSize / 2), gp.screenHeight / 2 - (tileSize / 2), tileSize, tileSize, null);
            }
        }

        // Draw the bullet if active
        if (bulletActive) {
            g2.setColor(Color.RED);
            g2.fillOval(bulletX, bulletY, 10, 10); // Example size for the bullet
        }
    }

    public void shootBullet() {
        if (!bulletActive) {
            bulletDirection = direction;
            bulletX = worldX + gp.tileSize / 2;
            bulletY = worldY + gp.tileSize / 2;
            bulletActive = true;
        }
    }
}
