/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import entity.Player;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;



/**
 *
 * @author Omar
 */
//كلاسس الكائنااات

public class Entity {
  
    public int worldX,worldY;
    public int speed;

public BufferedImage up1,up2,down1,down2,left1,left2,right1,right2,bult;
   
public String  direction;
public int spriteCounter=0;
public int spriteNum=1;
//في هذا ريك بنقدر نخلي مستطيل صلب بس شفاف بنوخذ الx و y
public Rectangle solidArea; 
public  boolean collisionOn=false;
    
}
