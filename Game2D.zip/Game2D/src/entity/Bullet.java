package entity;

import game2d.GamePanle;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Bullet {

    GamePanle gp;
    public int x, y;
    public int speed = 10;
    public boolean isActive = false;
    private Image image;
    private Rectangle solidArea;

    public Bullet(GamePanle gp) {
        this.gp = gp;
        x = -100; // خارج الشاشة
        y = -100;
        solidArea = new Rectangle(0, 0, 10, 10); // حجم الرصاصة
        getBulletImage();
    }

    public void getBulletImage() {
        try {
            image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\res\\bullet.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        if (isActive) {
            x += speed;
            if (x > gp.screenWidth) {
                isActive = false;
            }
        }
    }

    public void draw(Graphics2D g2) {
        if (isActive) {
            g2.drawImage(image, x, y, gp.tileSize, gp.tileSize, null);
        }
    }
}
