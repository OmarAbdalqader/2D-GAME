package entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Follower {

    private BufferedImage image;
    private int x, y;
    private int speed;

    public Follower(int startX, int startY, int speed) {
        this.x = startX;
        this.y = startY;
        this.speed = speed;
        loadImage();
    }

    private void loadImage() {
        try {
            image = ImageIO.read(new File("C:\\Users\\Omar\\Documents\\NetBeansProjects\\Game2D\\src\\res\\player\\tiles\\Screenshot 2024-08-23 001652_1.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update(int playerX, int playerY) {
        // Update position to follow the player
        if (x < playerX) x += speed;
        if (x > playerX) x -= speed;
        if (y < playerY) y += speed;
        if (y > playerY) y -= speed;
    }

    public void draw(Graphics2D g2) {
        g2.drawImage(image, x, y, null);
    }

    // Getters and setters for x and y if needed
    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
}
