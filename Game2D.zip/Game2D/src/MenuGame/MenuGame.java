/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MenuGame;

import game2d.GamePanle;
import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author Omar
 */
public class MenuGame extends JFrame{
    
    public static void main(String[] args) {
        
        JFrame menufram=new JFrame();
        
       
        menufram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menufram.setResizable(false);
        menufram.setTitle("Menu 2D Game");
        Menu m=new Menu();
        menufram.add(m);
//    عشان تشوف الشاشه تظهر
        menufram.pack();
        menufram.setLocationRelativeTo(null);
        menufram.setVisible(true);
        //تشغيل الeunميثود
       
        menufram.setBackground(Color.GREEN);
        
        m.setBackground(Color.gray);
        
        
    }
    
    
}
