/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game2d;

import object.OBJ_Key;

/**
 *
 * @author Omar
 */
public class AssetSetter {
    
    GamePanle gp;

    public AssetSetter(GamePanle gp) {
    this.gp=gp;
    }
    
    public void setObject(){
    
    gp.obj[0]=new OBJ_Key();
    gp.obj[0].worldx=23*gp.tileSize;
     gp.obj[0].worldy=7*gp.tileSize;
     
      gp.obj[1]=new OBJ_Key();
    gp.obj[1].worldx=23*gp.tileSize;
     gp.obj[1].worldy=40*gp.tileSize;
    
    }
    
    
    
}
