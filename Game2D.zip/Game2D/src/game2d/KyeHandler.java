package game2d;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KyeHandler implements KeyListener {

    public boolean upPreassed, downPreassed, leftPreassed, rightPreassed, spacePreassed, nPreassed,bult;

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W) {
            upPreassed = true;
        }
        if (code == KeyEvent.VK_S) {
            downPreassed = true;
        }
        if (code == KeyEvent.VK_A) {
            leftPreassed = true;
        }
        if (code == KeyEvent.VK_D) {
            rightPreassed = true;
        }
        if (code == KeyEvent.VK_SPACE) {
            spacePreassed = true;
        }
        if (code == KeyEvent.VK_N) {
            nPreassed = true;
        }
         if (code == KeyEvent.VK_N) {
            bult = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W) {
            upPreassed = false;
        }
        if (code == KeyEvent.VK_S) {
            downPreassed = false;
        }
        if (code == KeyEvent.VK_A) {
            leftPreassed = false;
        }
        if (code == KeyEvent.VK_D) {
            rightPreassed = false;
        }
        if (code == KeyEvent.VK_SPACE) {
            spacePreassed = false;
        }
        if (code == KeyEvent.VK_N) {
            nPreassed = false;
        }
        if (code == KeyEvent.VK_N) {
            bult = false;
        }
    }
}
