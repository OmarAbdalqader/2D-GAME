/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package game2d;

import MenuGame.Menuu;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *
 * @author Omar
 */
public class Game2D extends JFrame{

    /**
     * @param args the command line arguments
     */
      public JButton startButton;
    public JButton exitButton;
    public static void main(String[] args) {
//      MenuGame.Menuu m=new Menuu();
        
        
      
              
       JFrame frame =new JFrame();
//      frame.dispose();
  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setTitle("2D Game");
        GamePanle gamepanle=new GamePanle();
        frame.add(gamepanle);
//    عشان تشوف الشاشه تظهر
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        //تشغيل الeunميثود
        gamepanle.StartGameThread();
        frame.setBackground(Color.GREEN);
        
        gamepanle.setBackground(Color.gray);
    }


 

}
    
    

