/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game2d;

import entity.Entity;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author Omar
 */
public class Collision {

    public GamePanle gp;

    public Collision(GamePanle gp) {
    this.gp=gp;
    
    }
    
    
      public void checkTile(Entity entity) {
    //بدنا نعرف x and yللعالم
    int entityleftworldX=entity.worldX+entity.solidArea.x;
    int entityRightworldX=entity.worldX+entity.solidArea.x + entity.solidArea.width;
    int entityTopworldY=entity.worldY+entity.solidArea.y;
    int entityBottomworldY=entity.worldY+entity.solidArea.y + entity.solidArea.height;
    
    int entityleftCol=entityleftworldX/gp.tileSize;
    int entityRightCol=entityRightworldX/gp.tileSize;
    int entityTopRow=entityTopworldY/gp.tileSize;
    int entityBottomRow=entityBottomworldY/gp.tileSize;
    
    int tileNum1,tileNum2;
    
          switch (entity.direction) {
              case "up":
                  entityTopRow=(entityTopworldY-entity.speed)/gp.tileSize;
                   tileNum1=gp.tileM.mapTileNum[entityleftCol][entityTopRow];
                   tileNum2=gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                   if (gp.tileM.tile[tileNum1].collision==true || gp.tileM.tile[tileNum2].collision==true) {
                      entity.collisionOn=true;
                  }
                  break;
                  
                  case "down":
                       entityBottomRow=(entityBottomworldY-entity.speed)/gp.tileSize;
                   tileNum1=gp.tileM.mapTileNum[entityleftCol][entityBottomRow];
                   tileNum2=gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                   if (gp.tileM.tile[tileNum1].collision==true || gp.tileM.tile[tileNum2].collision==true) {
                      entity.collisionOn=true;
                  }
                  break;
                  
                  case "left":
                           entityleftCol=(entityleftworldX-entity.speed)/gp.tileSize;
                   tileNum1=gp.tileM.mapTileNum[entityleftCol][entityTopRow];
                   tileNum2=gp.tileM.mapTileNum[entityleftCol][entityBottomRow];
                   if (gp.tileM.tile[tileNum1].collision==true || gp.tileM.tile[tileNum2].collision==true) {
                      entity.collisionOn=true;
                          
                  }
                  break;
                  
                  case "right":
                       entityRightCol=(entityRightworldX-entity.speed)/gp.tileSize;
                   tileNum1=gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                   tileNum2=gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                   if (gp.tileM.tile[tileNum1].collision==true || gp.tileM.tile[tileNum2].collision==true) {
                      entity.collisionOn=true;
                  }
                  break;
              default:
                  throw new AssertionError();
          }
    }
    
}
