package object;

import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Omar
 */
public class OBJ_Key extends SuperObject {

    public OBJ_Key() {
        name = "Key";
        try {
            // تأكد من وضع الصورة في المجلد الصحيح
            image = ImageIO.read(getClass().getResourceAsStream("/res/tile/Opject/key.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
