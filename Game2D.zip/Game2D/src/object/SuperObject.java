/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package object;

import game2d.GamePanle;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 *
 * @author Omar
 */
public class SuperObject {
    
    public BufferedImage image;
    public String name;
    public Boolean collision=false;
    public int worldx,worldy;    
    
    
    public void draw(Graphics2D g2,GamePanle gp){
    
    
    }
    
}
